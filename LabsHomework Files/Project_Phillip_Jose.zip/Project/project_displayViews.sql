spool project_Views.txt

select * from managers;
select * from femdrivers;
select * from numstaff;
select * from owners;
select * from registered;
select * from allocated;
select * from avgjob;
select * from numjobs;
select * from driverjobs;
select * from contractjobs;

spool off

