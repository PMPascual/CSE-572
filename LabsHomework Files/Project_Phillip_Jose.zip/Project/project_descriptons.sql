set linesize 80
set pagesize 55

SPOOL project_desc.txt

DESC office;
desc staff;
desc assignment;
desc taxi;
desc job;
desc business;
desc private;
desc contract;

spool off

