-- Team Name: Deal Team Six
-- CSE 572 Spring 2019
-- Project Option: The FastCabs
-- Purpose: Display table data
-- Author: Phillip Pascual - 005869470
-- Author: Jose Perez - 004371093

SELECT * FROM ppas.office;
SELECT * FROM ppas.staff;
SELECT * FROM ppas.taxi;
SELECT * FROM ppas.assignment;
SELECT * FROM ppas.private;
SELECT * FROM ppas.business;
SELECT * FROM ppas.contract;
SELECT * FROM ppas.job;
